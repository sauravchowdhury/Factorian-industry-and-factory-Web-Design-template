(function ($) {
    "use strict";
    
    jQuery(Document).ready(function($){
    
    $(".slide-wrapper").oulCarousel({
        item: 1,
        nav: true,
        dots: false,
        autoplay: false,
        loop: true,
    });
                            
                            
});
    

jQuery(window).load(function(){
    
    
    
    
}); 


}(jQuery)); |